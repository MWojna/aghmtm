i=0
while(True):
    LedPoint(i)
    i=(i+1)%4
    sleep(1/50)
    if KeyRead(0):
        break