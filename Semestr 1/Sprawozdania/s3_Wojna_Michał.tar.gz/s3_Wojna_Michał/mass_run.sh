#!/bin/bash

arg=$@
if [ -z "$arg" ]; then
	echo "Skrypt $0 wymaga argumentu obsługiwanego przez skrypt, 
ktory uruchamia i testuje
przykład: $0 -a -t -r -k -h"
exit 
fi

RED="\033[31m"
WHITE="\033[0m"
GREEN="\033[01;32m"

#lista=$(ls -1 ./osp*.sh ./procesy_*.sh ./potoki_*.sh )
lista="./osp_01.sh ./osp_02.sh ./osp_03.sh ./osp_04.sh ./osp_05.sh ./osp_06.sh ./osp_07.sh ./osp_08.sh ./osp_09.sh ./osp_10.sh ./osp_11.sh ./osp_12.sh ./osp_13.sh ./osp_14.sh ./osp_15.sh ./osp_16.sh ./osp_17.sh ./osp_18.sh ./osp_19.sh ./osp_20.sh ./osp_21.sh ./osp_22.sh ./osp_23.sh ./osp_24.sh ./osp_25.sh ./osp_26.sh ./osp_27.sh ./osp_28.sh ./osp_29.sh ./procesy_01.sh ./procesy_02.sh ./procesy_03.sh ./procesy_04.sh ./procesy_05.sh ./procesy_06.sh ./procesy_07.sh ./procesy_08.sh ./procesy_09.sh ./procesy_10.sh ./procesy_11.sh ./procesy_12.sh ./procesy_13.sh ./procesy_14.sh ./procesy_15.sh ./procesy_16.sh ./procesy_17.sh ./procesy_18.sh ./procesy_19.sh ./procesy_20.sh ./potoki_01.sh ./potoki_02.sh ./potoki_03.sh ./potoki_04.sh ./potoki_05.sh ./potoki_06.sh ./potoki_07.sh ./potoki_08.sh ./potoki_09.sh ./potoki_10.sh ./potoki_11.sh ./potoki_12.sh ./potoki_13.sh ./potoki_14.sh ./potoki_15.sh ./potoki_16.sh ./potoki_17.sh ./potoki_18.sh ./potoki_19.sh ./potoki_20.sh ./potoki_21.sh ./potoki_22.sh ./potoki_23.sh ./potoki_24.sh ./potoki_25.sh"

mkdir -p logi
rm -fr logi/log_std*.txt  # czyszczenie starych plikow log
liczba_ok=0
liczba_fail=0

for i in $lista 
do
	echo "
    $i $arg" | tee -a logi/log_stderr.txt | tee -a logi/log_stdout.txt >/dev/null

	if $i $arg 2>> logi/log_stderr.txt 1>> logi/log_stdout.txt
	then
		echo -e "${GREEN}OK${WHITE}     $i $arg" 
		((liczba_ok++))
	else
		echo -e "${RED}FAIL${WHITE}   $i $arg"
		((liczba_fail++))
	fi
done

echo -e "${GREEN}OK${WHITE}: $liczba_ok"
echo -e "${RED}FAIL${WHITE}:  $liczba_fail"

read -p "Czy chcesz zobaczyć logi? T - tak, N - nie: " TAK
if [ "$TAK" == "T" ]
then
set -x
less logi/log_stderr.txt
less logi/log_stdout.txt
set +x
fi
